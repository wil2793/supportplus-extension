$ErrorActionPreference = "Stop"
$token = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String('bnRuX2I4ODI1MjQyODA5NFEzSEFwenZ3NVBoTG1JdmJZYW8xY202d2dWY2RSVUplNUM='))
$zipUrl = "https://github.com/wil2793/supportplus-extension/raw/feature/initial/releases/v5.5.2.zip"

$bodyJson = '{
  "parent": { "database_id": "36f20e0684b98004b283ec713d3cde8a" },
  "properties": {
    "Version": { "title": [{ "text": { "content": "5.5.2" } }] },
    "Camios": { "rich_text": [{ "text": { "content": "Token Monday individual por usuario (base64), auto-sync solo tickets propios, eliminar tabla MSP_Config" } }] },
    "Activo": { "checkbox": false },
    "Archivo zip": { "files": [{ "name": "v5.5.2.zip", "type": "external", "external": { "url": "ZIPURL" } }] }
  }
}'

$bodyJson = $bodyJson.Replace("ZIPURL", $zipUrl)

$headers = @{
  "Authorization" = "Bearer $token"
  "Notion-Version" = "2022-06-28"
  "Content-Type" = "application/json"
}

try {
  $response = Invoke-RestMethod -Uri "https://api.notion.com/v1/pages" -Method Post -Headers $headers -Body ([System.Text.Encoding]::UTF8.GetBytes($bodyJson))
  Write-Output "OK - Page created: $($response.id)"
} catch {
  Write-Output "Error: $($_.Exception.Message)"
}
